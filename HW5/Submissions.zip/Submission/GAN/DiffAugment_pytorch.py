# Differentiable Augmentation for Data-Efficient GAN Training
# Shengyu Zhao, Zhijian Liu, Ji Lin, Jun-Yan Zhu, and Song Han
# https://arxiv.org/pdf/2006.10738

import numpy as np
import cv2
import torch
import torch.nn.functional as F


def DiffAugment(x, policy='', channels_first=True):
    if policy:
        if not channels_first:
            x = x.permute(0, 3, 1, 2)
        for p in policy.split(','):
            for f in AUGMENT_FNS[p]:
                x = f(x)
        if not channels_first:
            x = x.permute(0, 2, 3, 1)
        x = x.contiguous()
    return x


def rand_brightness(x):
    x = x + (torch.rand(x.size(0), 1, 1, 1, dtype=x.dtype, device=x.device) - 0.5)
    return x


def rand_saturation(x):
    x_mean = x.mean(dim=1, keepdim=True)
    x = (x - x_mean) * (torch.rand(x.size(0), 1, 1, 1, dtype=x.dtype, device=x.device) * 2) + x_mean
    return x


def rand_contrast(x):
    x_mean = x.mean(dim=[1, 2, 3], keepdim=True)
    x = (x - x_mean) * (torch.rand(x.size(0), 1, 1, 1, dtype=x.dtype, device=x.device) + 0.5) + x_mean
    return x


def rand_translation(x, ratio=0.125):
    shift_x, shift_y = int(x.size(2) * ratio + 0.5), int(x.size(3) * ratio + 0.5)
    translation_x = torch.randint(-shift_x, shift_x + 1, size=[x.size(0), 1, 1], device=x.device)
    translation_y = torch.randint(-shift_y, shift_y + 1, size=[x.size(0), 1, 1], device=x.device)
    grid_batch, grid_x, grid_y = torch.meshgrid(
        torch.arange(x.size(0), dtype=torch.long, device=x.device),
        torch.arange(x.size(2), dtype=torch.long, device=x.device),
        torch.arange(x.size(3), dtype=torch.long, device=x.device),
    )
    grid_x = torch.clamp(grid_x + translation_x + 1, 0, x.size(2) + 1)
    grid_y = torch.clamp(grid_y + translation_y + 1, 0, x.size(3) + 1)
    x_pad = F.pad(x, [1, 1, 1, 1, 0, 0, 0, 0])
    x = x_pad.permute(0, 2, 3, 1).contiguous()[grid_batch, grid_x, grid_y].permute(0, 3, 1, 2).contiguous()
    return x


def rand_cutout(x, ratio=0.5):
    ''' 
        Random Cutout Data Augmentation 
    Args:
        x (torch):      Pytorch image with shape (B, C, H, W)     
        ratio (float):  The cut ratio (usually 0.5)
    Returns:
        x (torch):      Pytorch image with cutout 
    '''
    B, C, H, W = x.shape

    #randomize B cut heights and widths
    cut_heights = torch.randint( low=int(0.25*H), high=int(0.50*H), size=(B,) ).to(x.device)    #(B,)
    cut_widths =  torch.randint( low=int(0.25*W), high=int(0.50*W), size=(B,) ).to(x.device)    #(B,)

    #create random top-left x and y positions for the cutouts. entire cut should fit on the image
    corner_y = (torch.rand(B, device=x.device)*(H-cut_heights)).long()   #(B,)
    corner_x = (torch.rand(B, device=x.device)*(W-cut_widths)).long()    #(B,)

    # breakpoint()
    # mask x to be 0 in cutout range.
    for b in range(B):
        x[b, :, corner_y[b]:(corner_y[b]+cut_heights[b]), corner_x[b]:(corner_x[b]+cut_widths[b])] = 0

    return x



AUGMENT_FNS = {
    'color': [rand_brightness, rand_saturation, rand_contrast],
    'translation': [rand_translation],
    'cutout': [rand_cutout],
}



if __name__ == "__main__":
    sample_path = "many_shot_dog/0.png"

    # Read Image Path
    img = np.array(cv2.imread(sample_path))
    img = img.astype(np.float32)[None, ...]

    # Convert img
    img = torch.from_numpy(img.transpose(0, 3, 1, 2))

    # Execute the cutout augmentation
    cutout_img = rand_cutout(img)

    # Convert back
    cutout_img = np.array(np.uint8(cutout_img.numpy().squeeze(0).transpose(1, 2, 0)))
    cv2.imwrite("cutout_img.png", cutout_img)


    print("Finished!")

